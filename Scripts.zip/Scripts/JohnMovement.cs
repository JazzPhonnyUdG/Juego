using UnityEngine;

public class JohnMovement
{
    float horizontal = Input.GetAxis("Horizontal");
}
