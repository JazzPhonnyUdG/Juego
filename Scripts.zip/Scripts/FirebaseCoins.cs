using UnityEngine;
using Firebase;
using Firebase.Extensions;
using Firebase.Firestore;

public class FirebaseCoins : MonoBehaviour
{
    FirebaseFirestore db;

    void Start()
    {
        FirebaseApp.CheckAndFixDependenciesAsync().ContinueWithOnMainThread(task =>
        {
            if (task.Result == DependencyStatus.Available)
            {
                db = FirebaseFirestore.DefaultInstance;
                Debug.Log("Firebase listo");

                ObtenerMonedas();
            }
            else
            {
                Debug.LogError("Error con Firebase ❌");
            }
        });
    }

    void ObtenerMonedas()
    {
        if (db == null) return;

        DocumentReference docRef = db.Collection("users").Document("jugador1");

        docRef.GetSnapshotAsync().ContinueWithOnMainThread(task =>
        {
            if (task.IsCompleted && task.Result.Exists)
            {
                int coins = task.Result.GetValue<int>("coins");
                Debug.Log("Monedas actuales: " + coins);
            }
            else
            {
                Debug.LogError("No se pudieron obtener las monedas ❌");
            }
        });
    }

    public void SumarMonedas(int cantidad)
    {
        if (db == null)
        {
            Debug.LogError("Firebase aún no está listo ❌");
            return;
        }

        DocumentReference docRef = db.Collection("users").Document("jugador1");

        docRef.UpdateAsync("coins", FieldValue.Increment(cantidad)).ContinueWithOnMainThread(task =>
        {
            if (task.IsCompleted)
            {
                Debug.Log("Monedas sumadas 🔥");
                ObtenerMonedas();
            }
            else
            {
                Debug.LogError("Error al sumar monedas ❌");
            }
        });
    }
}