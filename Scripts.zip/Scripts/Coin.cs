using UnityEngine;

public class Coin : MonoBehaviour
{
    public int valor = 1;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            FirebaseCoins manager = FindObjectOfType<FirebaseCoins>();

            if (manager != null)
            {
                manager.SumarMonedas(valor);
            }
            else
            {
                Debug.LogError("No se encontró FirebaseCoins ❌");
            }

            Destroy(gameObject);
        }
    }
}