using UnityEngine;

public class JohnMovement1 : MonoBehaviour
{
    private Rigidbody2D rb2d;
    private float horizontal;
    private Animator animator; 
    
    [Header("Movimiento")]
    [SerializeField] private float speed = 8f; 
    [SerializeField] private float jumpForce = 12f; 

    [Header("Detección de Suelo")]
    [SerializeField] private bool isGrounded;
    [SerializeField] private Transform groundCheck; 
    [SerializeField] private float checkRadius = 0.2f;
    [SerializeField] private LayerMask groundLayer; 

    [Header("Disparo")]
    [SerializeField] private GameObject bulletPrefab; 
    [SerializeField] private Transform firePoint;     
    [SerializeField] private float bulletSpeed = 20f;

    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>(); 
        animator = GetComponent<Animator>();

        if (rb2d != null)
        {
            rb2d.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb2d.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            rb2d.freezeRotation = true;
        }
    }

    void Update()
    {
        // "Horizontal" detecta automáticamente: Flecha Izquierda/Derecha y A/D
        horizontal = Input.GetAxisRaw("Horizontal");
        
        if (animator != null)
        {
            animator.SetBool("Running", horizontal != 0.0f);
        }

        isGrounded = Physics2D.OverlapCircle(groundCheck.position, checkRadius, groundLayer);

        // Saltamos con Flecha Arriba (UpArrow) o con la W
        if ((Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow)) && isGrounded)
        {
            Jump();
        }

        // Disparamos con Espacio o Control Izquierdo
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.LeftControl)) 
        {
            Shoot();
        }

        Flip();
    }

    private void FixedUpdate() 
    {
        // Movimiento físico
        rb2d.linearVelocity = new Vector2(horizontal * speed, rb2d.linearVelocity.y);
    }

    private void Jump()
    {
        rb2d.linearVelocity = new Vector2(rb2d.linearVelocity.x, jumpForce);
    }

    private void Shoot()
    {
        if (bulletPrefab != null && firePoint != null)
        {
            // Usamos la rotación del firePoint para que la bala sepa a dónde ir
            GameObject bullet = Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
            
            // Pasamos la dirección a la escala de la bala para que no salga al revés
            float direction = transform.localScale.x;
            bullet.transform.localScale = new Vector3(direction, 1, 1);
        }
    }

    private void Flip()
    {
        if (horizontal > 0) transform.localScale = new Vector3(1, 1, 1);
        else if (horizontal < 0) transform.localScale = new Vector3(-1, 1, 1);
    }
}