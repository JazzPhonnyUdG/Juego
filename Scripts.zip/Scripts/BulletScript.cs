using UnityEngine;

public class BulletScript : MonoBehaviour
{
    public float speed = 20f; 
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        if (rb != null)
        {
            // Usamos transform.right para que respete la dirección del disparo
            rb.linearVelocity = transform.right * speed;
        }

        // Destrucción de seguridad por si nunca choca (3 segundos)
        Destroy(gameObject, 3f);
    }

    // EVENTO FINAL: Se activa cuando la bala toca algo
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) return; 

        // Si la bala tiene una animación de impacto, podrías activarla aquí.
        // Por ahora, la destruimos directamente:
        Desaparecer();
    }

    // ESTA ES LA FUNCIÓN QUE DEBES PONER EN EL EVENTO DE ANIMACIÓN
    public void Desaparecer()
    {
        Destroy(gameObject);
    }
}