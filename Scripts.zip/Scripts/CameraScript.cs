using UnityEngine;

public class CameraScript : MonoBehaviour
{
    // Las variables públicas van aquí afuera para que aparezcan en el Inspector
    public GameObject John;

    void Update()
    {
        // Verificamos que John no sea nulo para evitar errores en la consola
        if (John != null)
        {
            // Creamos una nueva posición basada en la de John
            // Mantenemos el eje Y y Z de la cámara para que no se mueva raro
            Vector3 newPosition = transform.position;
            
            newPosition.x = John.transform.position.x;

            // Aplicamos la nueva posición a la cámara
            transform.position = newPosition;
        }
    }
}